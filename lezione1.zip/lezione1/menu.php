<ul id="menu">
    <li><a href="index.php?">home</a></li>
    <li><a href="index.php?pagina=1">pagina 1</a></li>
    <li><a href="index.php?pagina=2">pagina 2</a></li>
</ul>