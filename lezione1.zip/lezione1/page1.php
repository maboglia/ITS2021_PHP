<h1>Calcolatrice</h1>

<form action="" method="post">

<input type="number" name="valore1" placeholder="valore 1">
<input type="number" name="valore2" placeholder="valore 2">

<input type="submit" value="calcola il risultato">


</form>


<?php  require 'script_calcoli.php'; ?>
