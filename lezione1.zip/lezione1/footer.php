
<script src="js/script.js"></script>
</body>
<!-- qui si chiude il documento html -->
</html>